import React, { useMemo, useState } from "react";
import Banner from "../components/Banner";
import CatagoryNav from "../components/CatagoryNav";
import ProductCard from "../components/ProductCard";
import Footer from "../components/Footer";
import { products } from "../constants/data.js";

const Home = () => {
  const [activeCategory, setActiveCategory] = useState("Popular");

  const filtered = useMemo(() => {
    if (activeCategory === "Popular") {
      return products.filter((p) => p.popular === true);
    }

    const key = (activeCategory || "").toLowerCase();
    return products.filter((p) => (p.category || "").toLowerCase() === key);
  }, [activeCategory]);

  return (
    <div>
      <Banner />
      <CatagoryNav value={activeCategory} onChange={setActiveCategory} />

      <div className="p-[10px] bg-[#f2f2f2]">
        {!filtered.length ? (
          <div className="p-6 text-center text-slate-500">
            No products found in this selection.
          </div>
        ) : (
          <div className="grid grid-cols-1 items-stretch gap-4 p-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {filtered.map((p) => (
              <ProductCard key={p.id} p={p} />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default Home;
