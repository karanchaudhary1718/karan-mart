// src/components/Footer.jsx
import React from "react";

const links = {
  categories: [
    { label: "Service Parts", href: "#" },
    { label: "Steering & Suspension", href: "#" },
    { label: "Brakes", href: "#" },
    { label: "Filters", href: "#" },
    { label: "Electricals", href: "#" },
  ],
  service: [
    { label: "Track Order", href: "#" },
    { label: "Returns & Refunds", href: "#" },
    { label: "Shipping Info", href: "#" },
    { label: "Warranty", href: "#" },
    { label: "Help Center", href: "#" },
  ],
  company: [
    { label: "About Us", href: "#" },
    { label: "Careers", href: "#" },
    { label: "Contact", href: "#" },
    { label: "Privacy Policy", href: "#" },
    { label: "Terms of Use", href: "#" },
  ],
};

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-white">
      {/* <div className="h-1 w-full bg-[#1e88e5]" /> */}
      <div className="border-b border-slate-200 bg-slate-50">
        <div className="mx-auto flex max-w-[1200px] flex-col items-center gap-3 px-4 py-6 text-center sm:flex-row sm:justify-between sm:text-left md:px-6">
          <div className="max-w-[600px]">
            <h4 className="text-base font-semibold text-slate-800">
              Get updates & exclusive offers
            </h4>
            <p className="text-sm text-slate-500">
              Join our mailing list for new arrivals, deals and garage tips.
            </p>
          </div>
          <form
            onSubmit={(e) => e.preventDefault()}
            className="flex w-full max-w-[420px] items-center rounded-full border border-slate-200 bg-white pl-4 pr-2 py-1.5"
          >
            <input
              type="email"
              required
              placeholder="Enter your email"
              className="min-w-0 flex-1 border-0 bg-transparent text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-0"
            />
            <button
              type="submit"
              className="ml-2 inline-flex h-9 items-center justify-center rounded-full bg-[#1e88e5] px-4 text-sm font-semibold text-white transition hover:brightness-95 active:translate-y-px"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>

      <div className="mx-auto max-w-[1200px] px-4 py-10 md:px-6">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <a href="/" className="inline-block">
              <img
                src="https://d2p4skp3azwb5a.cloudfront.net/media/logo/stores/1/autozilla_logo_small.png"
                alt="Logo"
                className="h-10 w-auto"
              />
            </a>
            <p className="mt-4 text-sm leading-6 text-slate-600">
              Your trusted destination for quality auto parts at fair prices.
              Fast shipping across India, easy returns, and dependable support.
            </p>

            {/* Contact badges */}
            <div className="mt-5 flex flex-wrap gap-2">
              <a
                href="tel:+919027352976"
                className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm text-slate-700 hover:border-slate-300 hover:bg-slate-100"
              >
                <img
                  src="https://d2p4skp3azwb5a.cloudfront.net/media//custom_icons/PhoneIcon.png"
                  alt="Call"
                  className="h-4 w-4"
                />
                +91 90273 52976
              </a>
              <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-sm text-slate-700">
                Free delivery above ₹499
              </span>
            </div>
          </div>

          {/* Shop by Category */}
          <div>
            <h5 className="text-sm font-semibold uppercase tracking-wide text-slate-800">
              Shop by Category
            </h5>
            <ul className="mt-4 space-y-2 text-sm">
              {links.categories.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    className="text-slate-600 transition hover:text-[#1e88e5]"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h5 className="text-sm font-semibold uppercase tracking-wide text-slate-800">
              Customer Service
            </h5>
            <ul className="mt-4 space-y-2 text-sm">
              {links.service.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    className="text-slate-600 transition hover:text-[#1e88e5]"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h5 className="text-sm font-semibold uppercase tracking-wide text-slate-800">
              Company
            </h5>
            <ul className="mt-4 space-y-2 text-sm">
              {links.company.map((l) => (
                <li key={l.label}>
                  <a
                    href={l.href}
                    className="text-slate-600 transition hover:text-[#1e88e5]"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>

            {/* Socials */}
            <div className="mt-5 flex items-center gap-3">
              <a
                href="#"
                aria-label="Instagram"
                className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 hover:text-[#1e88e5]"
              >
                {/* Instagram */}
                <svg
                  viewBox="0 0 24 24"
                  width="16"
                  height="16"
                  fill="currentColor"
                >
                  <path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7Zm5 3.5a5.5 5.5 0 1 1 0 11.001A5.5 5.5 0 0 1 12 7.5Zm0 2a3.5 3.5 0 1 0 0 7.001 3.5 3.5 0 0 0 0-7ZM18 6.8a1 1 0 1 1 0 2.001 1 1 0 0 1 0-2Z" />
                </svg>
              </a>
              <a
                href="#"
                aria-label="Facebook"
                className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 hover:text-[#1e88e5]"
              >
                {/* Facebook */}
                <svg
                  viewBox="0 0 24 24"
                  width="16"
                  height="16"
                  fill="currentColor"
                >
                  <path d="M13.5 9H15V6h-1.5C11.57 6 10 7.57 10 9.5V11H8v3h2v6h3v-6h2.1l.4-3H13v-1.5c0-.28.22-.5.5-.5Z" />
                </svg>
              </a>
              <a
                href="#"
                aria-label="YouTube"
                className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-600 transition hover:border-slate-300 hover:bg-slate-50 hover:text-[#1e88e5]"
              >
                {/* YouTube */}
                <svg
                  viewBox="0 0 24 24"
                  width="16"
                  height="16"
                  fill="currentColor"
                >
                  <path d="M23 7.5s-.2-1.5-.8-2.2c-.8-.8-1.7-.8-2.1-.8C16.7 4.3 12 4.3 12 4.3h0s-4.7 0-8.1.2c-.4 0-1.3 0-2.1.8C1.2 6 1 7.5 1 7.5S.8 9.2.8 11v2c0 1.8.2 3.5.2 3.5s.2 1.5.8 2.2c.8.8 1.9.8 2.4.9 1.7.2 7.8.2 7.8.2s4.7 0 8.1-.2c.4 0 1.3 0 2.1-.8.6-.7.8-2.2.8-2.2s.2-1.7.2-3.5v-2c0-1.8-.2-3.5-.2-3.5ZM9.8 14.8V8.9l6 2.9-6 3Z" />
                </svg>
              </a>
            </div>
          </div>
        </div>

        {/* Payments / badges */}
        <div className="mt-10 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 pt-6">
          <p className="text-sm text-slate-500">
            Secure payments via UPI, Cards, Net Banking
          </p>
          <div className="flex items-center gap-3">
            {/* Simple payment placeholders */}
            <span className="rounded border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-600">
              UPI
            </span>
            <span className="rounded border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-600">
              VISA
            </span>
            <span className="rounded border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-600">
              MasterCard
            </span>
            <span className="rounded border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-slate-600">
              RuPay
            </span>
          </div>
        </div>
      </div>

      <div className="border-t border-slate-200 bg-slate-50">
        <div className="mx-auto flex max-w-[1200px] flex-col items-center justify-between gap-3 px-4 py-4 text-center text-sm text-slate-600 md:flex-row md:px-6">
          <p>© {year} YourStore. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-4">
            <a href="#" className="hover:text-[#1e88e5]">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-[#1e88e5]">
              Terms
            </a>
            <a href="#" className="hover:text-[#1e88e5]">
              Sitemap
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
