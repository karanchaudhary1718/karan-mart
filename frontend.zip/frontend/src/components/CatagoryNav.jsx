import React from "react";
import { categories } from "../constants/data.js";

const CatagoryNav = ({ value = "ALL", onChange = () => {} }) => {
  return (
    <>
      <div className="px-[10px] bg-[#f2f2f2]">
        <div
          className="
            h-[70px] flex items-center
            overflow-x-auto overflow-y-hidden whitespace-nowrap
            px-2 space-x-2
            md:justify-center
          "
        >
          {categories.map((cat) => {
            const isActive = value === cat.key;
            return (
              <button
                key={cat.key}
                onClick={() => onChange(cat.key)}
                className={`
                  flex shrink-0 cursor-pointer items-center
                  rounded-[10px] px-[10px] py-[6px]
                  border-[2px] bg-white shadow-sm
                  transition mx-[4px]
                  ${
                    isActive
                      ? "border-[#1e88e5] text-[#1e88e5]"
                      : "border-[rgb(199,215,250)] text-slate-700"
                  }
                `}
              >
                <span className="w-[26px] h-[26px] mr-[8px] inline-block">
                  <img
                    src={cat.src}
                    alt={cat.label}
                    className="w-full h-full object-contain"
                  />
                </span>
                <span className="text-[13px] font-medium whitespace-nowrap">
                  {cat.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <style>{`
        .cat-scroll::-webkit-scrollbar { height: 6px; }
        .cat-scroll::-webkit-scrollbar-thumb { background: transparent; border-radius: 10px; }
        .cat-scroll:hover::-webkit-scrollbar-thumb { background: rgb(202, 218, 250); }
        .cat-scroll { scrollbar-width: thin; scrollbar-color: transparent transparent; }
        .cat-scroll:hover { scrollbar-color: rgb(202, 218, 250) transparent; }
      `}</style>
    </>
  );
};

export default CatagoryNav;
