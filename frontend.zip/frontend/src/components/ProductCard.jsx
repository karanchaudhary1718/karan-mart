import React from "react";

const rupee = (n) => `₹${Number(n).toLocaleString("en-IN")}`;

const ProductCard = ({ p }) => {
  const fit = p.fit ?? "contain";
  const imgClasses =
    fit === "contain"
      ? "h-full w-full object-contain bg-white p-2"
      : "h-full w-full object-cover object-center transition-transform duration-300 group-hover:scale-105";

  return (
    <div className="group flex h-full flex-col overflow-hidden rounded-lg bg-white shadow-lg transition-transform duration-300 hover:scale-[1.02]">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img src={p.img} alt={p.title} className={imgClasses} loading="lazy" />
        {p.badge && (
          <span className="absolute left-2 top-2 rounded bg-red-500 px-2 py-1 text-[11px] font-bold text-white">
            {p.badge}
          </span>
        )}
      </div>

      <div className="flex grow flex-col p-4">
        <p className="mb-1 line-clamp-1 text-[11px] uppercase text-gray-500">
          {p.category}
        </p>
        <h3 className="mb-1 line-clamp-2 text-[15px] font-semibold text-gray-800">
          {p.title}
        </h3>
        {p.desc && (
          <p className="mb-3 line-clamp-2 min-h-[40px] text-sm text-gray-600">
            {p.desc}
          </p>
        )}

        <div className="mt-1 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-red-600">
              {rupee(p.priceDetailer ?? p.price)}
            </span>
            {p.priceMRP && (
              <span className="text-xs text-gray-400 line-through">
                {rupee(p.priceMRP)}
              </span>
            )}
          </div>
          <p
            className={`text-sm font-medium ${
              p.stock === "In Stock" ? "text-green-600" : "text-orange-500"
            }`}
          >
            {p.stock ?? "In Stock"}
          </p>
        </div>

        <button className="mt-auto w-full rounded bg-blue-500 py-2 text-white transition-colors duration-200 hover:bg-blue-600">
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
