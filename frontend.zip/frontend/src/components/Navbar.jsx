import React, { useState } from "react";

const Navbar = () => {
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);

  return (
    <nav
      className="sticky top-0 z-50 w-full bg-white border-b border-slate-200"
      role="navigation"
      aria-label="Main"
    >
      <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-4 px-4 py-2.5 md:px-6">
        {/* LEFT: logo + search */}
        <div className="flex min-w-0 flex-1 items-center gap-3 sm:gap-4">
          <a className="shrink-0" href="/" aria-label="Autozilla Home">
            <img
              src="https://d2p4skp3azwb5a.cloudfront.net/media/logo/stores/1/autozilla_logo_small.png"
              alt="Autozilla"
              className="h-7 w-auto sm:h-8 md:h-9"
            />
          </a>

          {/* Search - Hidden on mobile, visible on tablet+ */}
          <form
            className="hidden sm:flex min-w-[160px] md:min-w-[220px] flex-1 items-center gap-2 rounded-full border border-slate-200 bg-slate-50 pl-3 pr-2 py-1.5"
            role="search"
            onSubmit={(e) => e.preventDefault()}
          >
            <input
              id="search"
              type="text"
              placeholder="Search by parts name"
              maxLength={128}
              aria-label="Search by parts name"
              className="min-w-0 flex-1 border-0 bg-transparent text-[14px] font-sans text-slate-800 placeholder:text-slate-400 placeholder:font-normal focus:outline-none focus:ring-0 focus:border-transparent"
            />

            {/* Search button */}
            <button
              type="submit"
              title="Search"
              aria-label="Search"
              className="inline-flex h-8 w-8 md:h-9 md:w-9 items-center justify-center rounded-full bg-[#1e88e5] text-white transition active:translate-y-[1px] hover:brightness-95 focus:outline-none focus:ring-0"
            >
              <svg
                viewBox="0 0 24 24"
                width="16"
                height="16"
                aria-hidden="true"
                focusable="false"
                className="shrink-0"
              >
                <path
                  d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5Zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14Z"
                  fill="currentColor"
                />
              </svg>
            </button>

            {/* Voice search - Hidden on mobile, visible on tablet+ */}
            <button
              type="button"
              title="Voice search"
              aria-label="Voice search"
              className="hidden md:inline-flex h-8 w-8 md:h-9 md:w-9 items-center justify-center rounded-full bg-[#1e88e5] transition active:translate-y-[1px] hover:brightness-95 focus:outline-none focus:ring-0"
            >
              <img
                src="https://d2p4skp3azwb5a.cloudfront.net/media//custom_icons/mic_search_icon.png"
                alt="Mic"
                className="h-4 w-4 md:h-[18px] md:w-[18px] invert"
              />
            </button>
          </form>
        </div>

        {/* RIGHT: wishlist/cart/phone/sign in */}
        <div className="flex items-center gap-2 sm:gap-3 md:gap-3.5">
          {/* Mobile search button - Visible only on mobile */}
          <button
            type="button"
            title="Search"
            aria-label="Search"
            className="inline-flex sm:hidden h-9 w-9 items-center justify-center rounded-full bg-[#1e88e5] text-white transition active:translate-y-[1px] hover:brightness-95 focus:outline-none focus:ring-0"
            onClick={() => setIsSearchExpanded(true)}
          >
            <svg
              viewBox="0 0 24 24"
              width="18"
              height="18"
              aria-hidden="true"
              focusable="false"
            >
              <path
                d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5Zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14Z"
                fill="currentColor"
              />
            </svg>
          </button>

          {/* Wishlist */}
          <a
            href="#"
            aria-label="Wishlist"
            className="relative inline-flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-full border border-slate-200 bg-slate-50 transition hover:border-slate-300 hover:bg-slate-100 focus:outline-none focus:ring-0"
          >
            <img
              src="https://d2p4skp3azwb5a.cloudfront.net/media//custom_icons/WishlistIcon.png"
              alt="Wishlist"
              className="h-4 w-4 sm:h-[18px] sm:w-[18px]"
            />
            <span className="absolute -right-1 -top-1 inline-block h-3.5 w-3.5 sm:h-4 sm:w-4 rounded-full bg-rose-500 text-[9px] sm:text-[10px] font-bold leading-3.5 sm:leading-4 text-white text-center">
              0
            </span>
          </a>

          {/* Cart */}
          <a
            href="#"
            aria-label="Cart"
            className="relative inline-flex h-9 w-9 sm:h-10 sm:w-10 items-center justify-center rounded-full border border-slate-200 bg-slate-50 transition hover:border-slate-300 hover:bg-slate-100 focus:outline-none focus:ring-0"
          >
            <img
              src="https://d2p4skp3azwb5a.cloudfront.net/media//custom_icons/CartIcon.png"
              alt="Cart"
              className="h-4 w-4 sm:h-[18px] sm:w-[18px]"
            />
            <span className="absolute -right-1 -top-1 inline-block h-3.5 w-3.5 sm:h-4 sm:w-4 rounded-full bg-rose-500 text-[9px] sm:text-[10px] font-bold leading-3.5 sm:leading-4 text-white text-center">
              0
            </span>
          </a>

          {/* Phone - Hidden on mobile, visible on tablet+ */}
          <a
            href="tel:+919027352976"
            aria-label="Call"
            className="hidden sm:inline-flex h-9 w-9 md:h-10 md:w-10 items-center justify-center rounded-full border border-slate-200 bg-slate-50 transition hover:border-slate-300 hover:bg-slate-100 focus:outline-none focus:ring-0"
          >
            <img
              src="https://d2p4skp3azwb5a.cloudfront.net/media//custom_icons/PhoneIcon.png"
              alt="Call"
              className="h-4 w-4 md:h-[18px] md:w-[18px]"
            />
          </a>

          {/* Sign in - Hidden on mobile, visible on tablet+ */}
          <div className="hidden sm:block">
            <button
              type="button"
              className="rounded-full border border-[#1e88e5] px-3 py-1.5 md:px-3.5 md:py-2 text-sm font-sans font-semibold text-[#1e88e5] transition hover:bg-[#1e88e5] hover:text-white focus:outline-none focus:ring-0"
            >
              Sign In
            </button>
          </div>
        </div>
      </div>

      {/* Expanded search for mobile */}
      {isSearchExpanded && (
        <div className="sm:hidden px-4 py-2 bg-white border-t border-slate-200">
          <form
            className="flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 pl-3 pr-2 py-1.5"
            role="search"
            onSubmit={(e) => {
              e.preventDefault();
              setIsSearchExpanded(false);
            }}
          >
            <input
              type="text"
              placeholder="Search by parts name"
              maxLength={128}
              aria-label="Search by parts name"
              className="min-w-0 flex-1 border-0 bg-transparent text-[14px] font-sans text-slate-800 placeholder:text-slate-400 placeholder:font-normal focus:outline-none focus:ring-0 focus:border-transparent"
              autoFocus
            />
            <button
              type="button"
              title="Close search"
              aria-label="Close search"
              className="inline-flex h-8 w-8 items-center justify-center rounded-full text-slate-500 transition hover:bg-slate-200 focus:outline-none focus:ring-0"
              onClick={() => setIsSearchExpanded(false)}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path
                  d="M18 6L6 18M6 6l12 12"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </svg>
            </button>
            <button
              type="submit"
              title="Search"
              aria-label="Search"
              className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-[#1e88e5] text-white transition active:translate-y-[1px] hover:brightness-95 focus:outline-none focus:ring-0"
            >
              <svg viewBox="0 0 24 24" width="16" height="16">
                <path
                  d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5Zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14Z"
                  fill="currentColor"
                />
              </svg>
            </button>
          </form>
        </div>
      )}

      {/* Mobile bottom bar with sign in and phone */}
      <div className="sm:hidden flex items-center justify-between px-4 py-2 bg-slate-50 border-t border-slate-200">
        <a
          href="tel:+919027352976"
          aria-label="Call"
          className="inline-flex items-center gap-2 text-sm font-sans text-slate-700 transition hover:text-[#1e88e5] focus:outline-none focus:ring-0"
        >
          <img
            src="https://d2p4skp3azwb5a.cloudfront.net/media//custom_icons/PhoneIcon.png"
            alt="Call"
            className="h-4 w-4"
          />
          <span>Call</span>
        </a>

        <button
          type="button"
          className="rounded-full border border-[#1e88e5] px-4 py-2 text-sm font-sans font-semibold text-[#1e88e5] transition hover:bg-[#1e88e5] hover:text-white focus:outline-none focus:ring-0"
        >
          Sign In
        </button>
      </div>
    </nav>
  );
};

export default Navbar;