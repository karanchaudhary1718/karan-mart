import React from "react";
import Carousel from "react-multi-carousel";
import { bannerData } from "../constants/data.js";
import "react-multi-carousel/lib/styles.css";

const responsive = {
  desktop: { breakpoint: { max: 3000, min: 1024 }, items: 1 },
  tablet: { breakpoint: { max: 1024, min: 464 }, items: 1 },
  mobile: { breakpoint: { max: 464, min: 0 }, items: 1 },
};

const Banner = () => {
  return (
    <div className="w-full p-[10px] bg-[#f2f2f2]">
      <Carousel
        responsive={responsive}
        swipeable={false}
        draggable={false}
        infinite
        autoPlay
        autoPlaySpeed={3000}
        renderDotsOutside
        dotListClass="flex justify-center items-center py-3 gap-2"
        itemClass="px-0"
        containerClass="relative"
      >
        {bannerData.map((banner) => (
          <img
            key={banner.id}
            src={banner.url}
            alt="banner"
            className="w-full h-[280px] object-cover block"
          />
        ))}
      </Carousel>
    </div>
  );
};

export default Banner;
